package com.hcl.java.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.hcl.java.bean.User;
import com.hcl.java.dto.UserDto;
import com.hcl.java.exception.UserException;
import com.hcl.java.services.UserServiceImpl;

@RestController
public class UserController {
	
	@Autowired
	UserServiceImpl service;
	
	@PostMapping("/users")
	public ResponseEntity<User> addUser(@RequestBody User user) throws UserException{
		return new ResponseEntity<User>(service.addUser(user), HttpStatus.OK);
	}
	
	@GetMapping("/users")
	public ResponseEntity<List<User>> displayList() throws UserException{
		return new ResponseEntity<List<User>>(service.displayList(), HttpStatus.OK);
	}
	
	@GetMapping("/users/salary")
	public ResponseEntity<List<User>> displayBasedOnSalary() throws UserException{
		return new ResponseEntity<List<User>>(service.displayBasedOnSalary(), HttpStatus.OK);
	}
	
	@GetMapping("/users/name/designation")
	public ResponseEntity<List<UserDto>> salaryBasedOnNameDesignation() throws UserException{
		return new ResponseEntity<List<UserDto>>(service.salaryBasedOnNameDesignation(), HttpStatus.OK);
	}

}
