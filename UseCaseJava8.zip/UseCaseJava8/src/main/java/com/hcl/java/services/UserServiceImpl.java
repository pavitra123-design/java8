package com.hcl.java.services;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hcl.java.bean.User;
import com.hcl.java.dao.UserDao;
import com.hcl.java.dto.UserDto;
import com.hcl.java.exception.UserException;

@Service
public class UserServiceImpl implements IUserService{

	@Autowired
	UserDao dao;
	
	@Override
	public User addUser(User user) throws UserException{
		return dao.save(user);
	}
	
	@Override
	public List<User> displayList()throws UserException{
		return (List<User>) dao.findAll();
	}

	@Override
	public List<User> displayBasedOnSalary() throws UserException {
		List<User> users=dao.findAll();
		List<User> users1=users.stream().filter(u->u.getSalary()>5000).collect(Collectors.toList());
		return users1 ;
	}

	@Override
	public List<UserDto> salaryBasedOnNameDesignation() throws UserException {
		List<User> users=dao.findAll();
		String name;
		String des;
		double salary;
		
		List<UserDto> dtos=new ArrayList<UserDto>();
		List<User> user1=users.stream().filter(u->u.getSalary()<2000).collect(Collectors.toList());
		for (User user : user1) {
			UserDto dto=new UserDto();
			 name=user.getName();
			 des=user.getDesignation();
			 salary=user.getSalary()+1000;
			 dto.setName(name);
			 dto.setDesignation(des);
			 dto.setSalary(salary);
			 dtos.add(dto);
			 //System.out.println(dtos);
		}
		
		return dtos;
	}
}
