package com.hcl.java.services;

import java.util.List;

import com.hcl.java.bean.User;
import com.hcl.java.dto.UserDto;
import com.hcl.java.exception.UserException;

public interface IUserService {

	public User addUser(User user) throws UserException;
	
	public List<User> displayList()throws UserException;
	
	public List<User> displayBasedOnSalary() throws UserException;
	
	public List<UserDto> salaryBasedOnNameDesignation()throws UserException;
}
